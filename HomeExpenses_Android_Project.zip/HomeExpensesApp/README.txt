HOME EXPENSES Android project
Features: offline expense list, Paid/Unpaid toggles, add/remove expenses, automatic totals, local save, print/PDF.
To build APK:
1. Install Android Studio and Android SDK.
2. Open this folder in Android Studio.
3. Wait for Gradle sync.
4. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).
The APK will be created under app/build/outputs/apk/debug/app-debug.apk.
This environment does not have the Android SDK/Gradle build tool installed, so it cannot produce or verify the APK binary here.
